const data = require("./servus.js");

console.log(data.name("Hallo "));

require("./unterordner/hi.js");
require("./unterordner");