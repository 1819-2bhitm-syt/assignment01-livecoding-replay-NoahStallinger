let data = require("./erstes.js");

console.log(data);